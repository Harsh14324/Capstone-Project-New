# Campus Transport Optimization System

A complete full-stack campus transport optimization platform for smart route planning, demand simulation, fleet management, and event-driven operations. The project is built with a React + Vite frontend and Express backend and is designed for demo use and Vercel deployment.

## Project overview
The system addresses overload, route inefficiency, underutilized buses, delays, and poor demand visibility for campus transportation. The platform provides admins with live insights into students by pickup zone, bus occupancy, route efficiency, simulated demand forecasts, and response workflows for incidents such as bus breakdowns and delays.

## Problem statement
Campus transport systems often suffer from overcrowding at peak times, inefficient routing, poor vehicle allocation, and lack of real-time monitoring. Without actionable analytics, administrators struggle to optimize service quality and respond quickly to disruptions.

## Proposed solution
The application uses a zone-based student demand model, graph-based shortest path calculations, simulation-driven allocation recommendations, and event alerts. It presents a dashboard for operations, route optimization, demand simulation, and analytics in a SaaS-style interface.

## System architecture
- Frontend: React 18, Vite, React Router, Tailwind-inspired custom CSS, Recharts, Lucide icons
- Backend: Express.js with ES modules, rate limiting, CORS, Helmet, and demo data store
- Data layer: MongoDB Atlas ready via Mongoose, with offline demo mode when not configured
- Routes: Dijkstra shortest path algorithm and demand-aware optimization logic
- Deployment: separate frontend and backend Vercel projects

## Technology stack
- React
- Vite
- JavaScript
- Express.js
- Node.js
- MongoDB Atlas + Mongoose
- Axios
- Recharts
- Lucide React
- Helmet
- CORS
- dotenv
- express-rate-limit
- uuid

## Folder structure
- frontend/
- backend/
- README.md
- .gitignore
- create-zip.ps1

## Features
- Demo login access
- Dashboard stats and KPI cards
- Campus zones and student demand management
- Bus management with occupancy thresholds
- Graph-based route optimization using Dijkstra
- Demand simulation for morning, afternoon, evening, and normal hours
- Event-driven bus breakdown and delay handling
- Live operations and alert history
- Analytics and reporting pages
- Settings and configuration

## Algorithms used
- Dijkstra shortest path algorithm for campus graph traversal
- Demand-based allocation logic prioritizing high-demand zones
- Capacity-aware route assignment and state-aware occupancy summaries

## Database design
The project is designed to support MongoDB Atlas with models for zones, buses, routes, students, transport events, and simulation results. In local demo mode, the backend runs completely from in-memory demo data and remains compatible with API responses.

## API documentation
Primary API endpoints:
- GET /api/health
- GET /api/dashboard/stats
- GET /api/zones
- POST /api/zones
- PUT /api/zones/:id
- DELETE /api/zones/:id
- GET /api/buses
- POST /api/buses
- PUT /api/buses/:id
- DELETE /api/buses/:id
- PATCH /api/buses/:id/status
- GET /api/routes
- POST /api/routes/optimize
- GET /api/routes/:id
- POST /api/simulation/run
- GET /api/simulation/results
- GET /api/events
- POST /api/events/trigger
- GET /api/analytics/occupancy
- GET /api/analytics/demand

## Local installation
1. Open two terminals.
2. In backend/, run npm install and npm run dev.
3. In frontend/, run npm install and npm run dev.
4. Open the frontend at http://localhost:5173.
5. Use the demo login to access the dashboard.

## Environment variables
Frontend .env.example:
- VITE_API_URL=http://localhost:5000/api

Backend .env.example:
- PORT=5000
- MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/campus-transport
- CLIENT_ORIGIN=http://localhost:5173

## How to run frontend
cd frontend
npm install
npm run dev

## How to run backend
cd backend
npm install
npm run dev

## How to run simulation
Use the Demo Access dashboard and open the Demand Simulation page, then click Run simulation.

## Deployment to Vercel
### Frontend
- Import frontend as a separate Vercel project
- Build command: npm run build
- Output directory: dist
- Set VITE_API_URL to the deployed backend API URL

### Backend
- Import backend as a separate Vercel project
- Use the included backend/vercel.json
- Set MONGODB_URI and CLIENT_ORIGIN in the deployment environment

## Screenshots
Placeholder section: add screenshots after running the project locally or via deployment.

## Limitations and future scope
- This is a demo-ready solution built for college project showcase
- Real-time GPS integration is simulated rather than hardware-backed
- MongoDB is optional and the project falls back to demo mode when the URI is absent
- Future work can include authentication, live map tracking, and real scheduling optimization

## Build and validation
The project includes backend test coverage for health checks, Dijkstra route computation, and breakdown simulation. The frontend production build succeeds with Vite.

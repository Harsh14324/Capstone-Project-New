import mongoose from 'mongoose';

export async function connectDatabase() {
  const uri = process.env.MONGODB_URI;

  if (!uri) {
    console.log('MongoDB URI missing. Running in offline demo mode.');
    return null;
  }

  try {
    await mongoose.connect(uri, { serverSelectionTimeoutMS: 5000 });
    console.log('MongoDB connected successfully.');
    return mongoose.connection;
  } catch (error) {
    console.warn('MongoDB connection failed, continuing in demo mode:', error.message);
    return null;
  }
}

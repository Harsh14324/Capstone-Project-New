import { EventEmitter } from 'node:events';

const emitter = new EventEmitter();

export function getEventEmitter() {
  return emitter;
}

export function emitTransportEvent(type, payload = {}) {
  emitter.emit(type, payload);
  return { type, payload };
}

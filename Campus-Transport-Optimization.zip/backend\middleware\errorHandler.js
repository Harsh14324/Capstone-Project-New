export function notFoundHandler(req, res) {
  res.status(404).json({
    success: false,
    message: 'API route not found',
    data: { path: req.originalUrl },
  });
}

export function errorHandler(err, req, res, next) {
  const statusCode = err.statusCode || 500;
  res.status(statusCode).json({
    success: false,
    message: err.message || 'Internal server error',
    data: {
      stack: process.env.NODE_ENV === 'production' ? undefined : err.stack,
    },
  });
}

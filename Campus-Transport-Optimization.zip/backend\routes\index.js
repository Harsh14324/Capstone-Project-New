import express from 'express';

const router = express.Router();

router.get('/dashboard/stats', async (req, res) => {
  const { getDashboardStats } = await import('../services/transportService.js');
  const metrics = getDashboardStats();
  res.json({ success: true, message: 'Dashboard statistics loaded', data: metrics });
});

router.get('/zones', async (req, res) => {
  const { getZones } = await import('../services/transportService.js');
  res.json({ success: true, message: 'Zones retrieved', data: getZones() });
});

router.post('/zones', async (req, res) => {
  const { addZone } = await import('../services/transportService.js');
  const zone = addZone(req.body || {});
  res.status(201).json({ success: true, message: 'Zone created', data: zone });
});

router.put('/zones/:id', async (req, res) => {
  const { updateZone } = await import('../services/transportService.js');
  const zone = updateZone(req.params.id, req.body || {});
  res.json({ success: true, message: 'Zone updated', data: zone });
});

router.delete('/zones/:id', async (req, res) => {
  const { deleteZone } = await import('../services/transportService.js');
  const deleted = deleteZone(req.params.id);
  res.json({ success: true, message: 'Zone deleted', data: deleted });
});

router.get('/buses', async (req, res) => {
  const { getBuses } = await import('../services/transportService.js');
  res.json({ success: true, message: 'Buses retrieved', data: getBuses() });
});

router.post('/buses', async (req, res) => {
  const { addBus } = await import('../services/transportService.js');
  const bus = addBus(req.body || {});
  res.status(201).json({ success: true, message: 'Bus created', data: bus });
});

router.put('/buses/:id', async (req, res) => {
  const { updateBus } = await import('../services/transportService.js');
  const bus = updateBus(req.params.id, req.body || {});
  res.json({ success: true, message: 'Bus updated', data: bus });
});

router.delete('/buses/:id', async (req, res) => {
  const { deleteBus } = await import('../services/transportService.js');
  const deleted = deleteBus(req.params.id);
  res.json({ success: true, message: 'Bus deleted', data: deleted });
});

router.patch('/buses/:id/status', async (req, res) => {
  const { updateBusStatus } = await import('../services/transportService.js');
  const bus = updateBusStatus(req.params.id, req.body?.status, req.body?.details || {});
  res.json({ success: true, message: 'Bus status updated', data: bus });
});

router.get('/routes', async (req, res) => {
  const { getRoutes } = await import('../services/transportService.js');
  res.json({ success: true, message: 'Routes retrieved', data: getRoutes() });
});

router.post('/routes/optimize', async (req, res) => {
  const { optimizeRoutes } = await import('../services/transportService.js');
  const result = optimizeRoutes(req.body || {});
  res.json({ success: true, message: 'Route optimization completed', data: result });
});

router.get('/routes/:id', async (req, res) => {
  const { getRouteById } = await import('../services/transportService.js');
  const route = getRouteById(req.params.id);
  res.json({ success: true, message: 'Route retrieved', data: route });
});

router.post('/simulation/run', async (req, res) => {
  const { runSimulation } = await import('../services/simulationService.js');
  const result = runSimulation(req.body || {});
  res.status(201).json({ success: true, message: 'Simulation completed', data: result });
});

router.get('/simulation/results', async (req, res) => {
  const { getSimulationResults } = await import('../services/simulationService.js');
  res.json({ success: true, message: 'Simulation history retrieved', data: getSimulationResults() });
});

router.get('/events', async (req, res) => {
  const { getEvents } = await import('../services/transportService.js');
  res.json({ success: true, message: 'Events retrieved', data: getEvents() });
});

router.post('/events/trigger', async (req, res) => {
  const { triggerEvent } = await import('../services/eventService.js');
  const event = triggerEvent(req.body?.type, req.body?.payload || {});
  res.status(201).json({ success: true, message: 'Event triggered', data: event });
});

router.get('/analytics/occupancy', async (req, res) => {
  const { getOccupancyAnalytics } = await import('../services/transportService.js');
  res.json({ success: true, message: 'Occupancy analytics retrieved', data: getOccupancyAnalytics() });
});

router.get('/analytics/demand', async (req, res) => {
  const { getDemandAnalytics } = await import('../services/transportService.js');
  res.json({ success: true, message: 'Demand analytics retrieved', data: getDemandAnalytics() });
});

export default router;

import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import morgan from 'morgan';
import dotenv from 'dotenv';
import apiRoutes from './routes/index.js';
import { notFoundHandler, errorHandler } from './middleware/errorHandler.js';

dotenv.config();

export function createApp() {
  const app = express();

  app.set('trust proxy', 1);
  app.use(
    helmet({
      crossOriginResourcePolicy: false,
    })
  );

  app.use(
    cors({
      origin: (origin, callback) => {
        const allowedOrigins = [
          process.env.CLIENT_ORIGIN,
          'http://localhost:5173',
          'http://127.0.0.1:5173',
          'http://localhost:3000',
          'https://campus-transport-frontend.vercel.app',
          'https://campus-transport-backend.vercel.app',
        ].filter(Boolean);

        if (!origin || allowedOrigins.includes(origin)) {
          callback(null, true);
          return;
        }

        callback(new Error('CORS policy does not allow access from this origin.'));
      },
      credentials: true,
    })
  );

  app.use(express.json({ limit: '1mb' }));
  app.use(morgan('dev'));
  app.use(
    '/api',
    rateLimit({
      windowMs: 15 * 60 * 1000,
      max: 200,
      standardHeaders: true,
      legacyHeaders: false,
      message: 'Too many requests from this IP, please try again later.',
    })
  );

  app.get('/api/health', (req, res) => {
    res.status(200).json({
      success: true,
      message: 'Campus transport API is running',
      data: {
        status: 'healthy',
        uptime: process.uptime(),
        timestamp: new Date().toISOString(),
        mode: process.env.MONGODB_URI ? 'database-connected' : 'demo-mode',
      },
    });
  });

  app.use('/api', apiRoutes);
  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}

const app = createApp();

if (process.env.NODE_ENV !== 'test' && !process.env.VERCEL) {
  const port = Number(process.env.PORT || 5000);
  app.listen(port, () => {
    console.log(`Campus Transport API listening on http://localhost:${port}`);
  });
}

export default app;

import { v4 as uuidv4 } from 'uuid';

export const campusZones = [
  { id: 'A', name: 'North Campus', students: 265, demand: 92, peakDemand: 120, priority: 'High' },
  { id: 'B', name: 'South Campus', students: 220, demand: 81, peakDemand: 110, priority: 'High' },
  { id: 'C', name: 'East Campus', students: 180, demand: 70, peakDemand: 96, priority: 'Medium' },
  { id: 'D', name: 'West Campus', students: 210, demand: 76, peakDemand: 102, priority: 'High' },
  { id: 'E', name: 'Central Campus', students: 260, demand: 94, peakDemand: 128, priority: 'Critical' },
  { id: 'F', name: 'Hostel Area', students: 310, demand: 108, peakDemand: 144, priority: 'Critical' },
  { id: 'G', name: 'University Gate', students: 145, demand: 60, peakDemand: 88, priority: 'Medium' },
  { id: 'H', name: 'Residential Area', students: 188, demand: 72, peakDemand: 98, priority: 'Medium' },
];

export const zoneNetwork = {
  A: { B: 4, D: 5, E: 3 },
  B: { A: 4, C: 6, E: 4 },
  C: { B: 6, F: 7, H: 4 },
  D: { A: 5, E: 3, G: 5 },
  E: { A: 3, B: 4, D: 3, F: 5, H: 4, G: 6 },
  F: { C: 7, E: 5, H: 3 },
  G: { D: 5, E: 6, H: 6 },
  H: { C: 4, E: 4, F: 3, G: 6 },
};

export const defaultRoutes = [
  { id: 'route-1', name: 'North Loop', from: 'A', to: 'E', distance: 10.5, time: 16, status: 'Active' },
  { id: 'route-2', name: 'South Connector', from: 'B', to: 'F', distance: 12.4, time: 18, status: 'Active' },
  { id: 'route-3', name: 'East Shuttle', from: 'C', to: 'H', distance: 9.8, time: 14, status: 'Active' },
  { id: 'route-4', name: 'Gateway Route', from: 'G', to: 'D', distance: 11.1, time: 17, status: 'Monitoring' },
];

export function createDemoState() {
  const seededStudents = Array.from({ length: 100 }, (_, index) => ({
    id: `student-${index + 1}`,
    zoneId: campusZones[index % campusZones.length].id,
    name: `Student ${index + 1}`,
    registered: true,
  }));

  const buses = [
    { id: 'bus-1', registrationNumber: 'CB-101', capacity: 48, currentPassengers: 31, assignedRoute: 'route-1', status: 'Active', driverName: 'Aisha Khan', estimatedArrivalTime: '8 mins', occupancy: 65 },
    { id: 'bus-2', registrationNumber: 'CB-102', capacity: 45, currentPassengers: 24, assignedRoute: 'route-2', status: 'Active', driverName: 'Milan Roy', estimatedArrivalTime: '11 mins', occupancy: 53 },
    { id: 'bus-3', registrationNumber: 'CB-103', capacity: 50, currentPassengers: 46, assignedRoute: 'route-3', status: 'Delayed', driverName: 'Nadia Bose', estimatedArrivalTime: '17 mins', occupancy: 92 },
    { id: 'bus-4', registrationNumber: 'CB-104', capacity: 52, currentPassengers: 16, assignedRoute: 'route-4', status: 'Idle', driverName: 'Rohan Sen', estimatedArrivalTime: 'NA', occupancy: 31 },
    { id: 'bus-5', registrationNumber: 'CB-105', capacity: 42, currentPassengers: 38, assignedRoute: 'route-1', status: 'Active', driverName: 'Lena James', estimatedArrivalTime: '9 mins', occupancy: 90 },
    { id: 'bus-6', registrationNumber: 'CB-106', capacity: 48, currentPassengers: 18, assignedRoute: 'route-2', status: 'Maintenance', driverName: 'Samir Ali', estimatedArrivalTime: 'Maintenance', occupancy: 38 },
    { id: 'bus-7', registrationNumber: 'CB-107', capacity: 50, currentPassengers: 43, assignedRoute: 'route-3', status: 'Active', driverName: 'Priya Joshi', estimatedArrivalTime: '10 mins', occupancy: 86 },
    { id: 'bus-8', registrationNumber: 'CB-108', capacity: 46, currentPassengers: 11, assignedRoute: 'route-4', status: 'Active', driverName: 'Arjun Das', estimatedArrivalTime: '7 mins', occupancy: 24 },
    { id: 'bus-9', registrationNumber: 'CB-109', capacity: 44, currentPassengers: 30, assignedRoute: 'route-2', status: 'Active', driverName: 'Karan Mal', estimatedArrivalTime: '12 mins', occupancy: 68 },
    { id: 'bus-10', registrationNumber: 'CB-110', capacity: 40, currentPassengers: 34, assignedRoute: 'route-1', status: 'Breakdown', driverName: 'Zara Khan', estimatedArrivalTime: 'Awaiting replacement', occupancy: 85 },
  ];

  return {
    zones: campusZones,
    buses,
    routes: defaultRoutes,
    students: seededStudents,
    events: [
      {
        id: uuidv4(),
        type: 'BUS_BREAKDOWN',
        title: 'Bus breakdown detected',
        severity: 'high',
        description: 'Bus CB-110 has broken down on route A-E.',
        timestamp: new Date().toISOString(),
      },
      {
        id: uuidv4(),
        type: 'HIGH_DEMAND',
        title: 'High demand alert',
        severity: 'medium',
        description: 'Hostel Area demand is above recommended threshold.',
        timestamp: new Date(Date.now() - 1800000).toISOString(),
      },
    ],
    simulationResults: [],
    alerts: 3,
  };
}

import { v4 as uuidv4 } from 'uuid';
import { getState } from './store.js';

export function triggerEvent(type, payload = {}) {
  const state = getState();
  const event = {
    id: uuidv4(),
    type,
    title: type.replace(/_/g, ' '),
    severity: payload.severity || 'medium',
    description: payload.description || `Transport event: ${type}`,
    timestamp: new Date().toISOString(),
    details: payload.details || {},
  };

  state.events.unshift(event);
  state.events = state.events.slice(0, 50);

  if (type === 'BUS_DELAYED') {
    const bus = state.buses.find((item) => item.id === payload.busId || item.registrationNumber === payload.busId);
    if (bus) {
      bus.status = 'Delayed';
      bus.delayMinutes = payload.delayMinutes || 15;
      bus.estimatedArrivalTime = payload.estimatedArrivalTime || `${bus.delayMinutes} min`;
    }
  }

  if (type === 'BUS_BREAKDOWN') {
    const bus = state.buses.find((item) => item.id === payload.busId || item.registrationNumber === payload.busId);
    if (bus) {
      bus.status = 'Breakdown';
      bus.delayMinutes = payload.delayMinutes || 25;
      bus.estimatedArrivalTime = 'Awaiting replacement';
    }
  }

  if (type === 'BUS_REPAIRED') {
    const bus = state.buses.find((item) => item.id === payload.busId || item.registrationNumber === payload.busId);
    if (bus) {
      bus.status = 'Active';
      bus.delayMinutes = 0;
      bus.estimatedArrivalTime = 'On time';
    }
  }

  if (type === 'ROUTE_CHANGED') {
    const route = state.routes.find((item) => item.id === payload.routeId);
    if (route) route.status = 'Adjusted';
  }

  if (type === 'HIGH_DEMAND') {
    state.alerts = (state.alerts || 0) + 1;
  }

  if (type === 'BUS_OVERLOADED') {
    const bus = state.buses.find((item) => item.id === payload.busId || item.registrationNumber === payload.busId);
    if (bus) bus.status = 'Delayed';
  }

  return event;
}

export function dijkstra(graph, start, end) {
  const distances = {};
  const previous = {};
  const visited = new Set();
  const nodes = Object.keys(graph);

  for (const node of nodes) {
    distances[node] = node === start ? 0 : Number.POSITIVE_INFINITY;
    previous[node] = null;
  }

  let current = start;
  while (current) {
    visited.add(current);
    const neighbors = graph[current] || {};

    for (const [neighbor, weight] of Object.entries(neighbors)) {
      if (visited.has(neighbor)) continue;
      const candidate = distances[current] + weight;
      if (candidate < distances[neighbor]) {
        distances[neighbor] = candidate;
        previous[neighbor] = current;
      }
    }

    let smallestNode = null;
    let smallestWeight = Number.POSITIVE_INFINITY;
    for (const node of nodes) {
      if (!visited.has(node) && distances[node] < smallestWeight) {
        smallestNode = node;
        smallestWeight = distances[node];
      }
    }
    current = smallestNode;
    if (current === null) break;
  }

  if (distances[end] === Number.POSITIVE_INFINITY) {
    return { path: [], distance: null };
  }

  const path = [];
  let cursor = end;
  while (cursor) {
    path.unshift(cursor);
    cursor = previous[cursor];
  }

  return { path, distance: distances[end] };
}

export function optimizeRoutes(zones, buses, graph) {
  const ranked = [...zones]
    .map((zone) => ({ ...zone, demandScore: zone.demand + zone.peakDemand * 0.7 }))
    .sort((a, b) => b.demandScore - a.demandScore);

  const selected = ranked.slice(0, Math.min(4, ranked.length));
  const routeAssignments = selected.map((zone, index) => {
    const bus = buses[index % buses.length] || buses[0];
    const route = dijkstra(graph, zone.id, 'E');
    return {
      zone: zone.name,
      zoneId: zone.id,
      busId: bus.id,
      priority: zone.priority,
      route: route.path,
      routeDistance: route.distance,
      recommendation: `${zone.name} is prioritized due to high booking demand and better capacity fit.`,
    };
  });

  const optimizedDistance = routeAssignments.reduce((sum, item) => sum + (item.routeDistance || 0), 0);
  const baselineDistance = selected.reduce((sum, zone) => sum + (graph[zone.id]?.E || 0), 0);

  return {
    originalRoute: 'Existing schedule',
    optimizedRoute: routeAssignments.map((item) => item.zone).join(' → '),
    originalDistance: baselineDistance,
    optimizedDistance,
    estimatedTimeSaved: `${Math.max(0, Math.round(baselineDistance - optimizedDistance))} min`,
    estimatedDistanceSaved: `${Math.max(0, baselineDistance - optimizedDistance).toFixed(1)} km`,
    demandCoverage: `${Math.min(100, Math.round(selected.reduce((sum, zone) => sum + zone.demand, 0) / 2.4))}%`,
    busUtilization: `${Math.min(100, Math.round((buses.filter((bus) => bus.status === 'Active').length / Math.max(1, buses.length)) * 100))}%`,
    assignments: routeAssignments,
    summary: 'Optimization prioritizes zones with the highest student demand and assigns buses with sufficient capacity to those clusters.',
  };
}

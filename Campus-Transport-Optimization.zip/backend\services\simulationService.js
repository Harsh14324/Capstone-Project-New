import { getState } from './store.js';

export function runSimulation(input = {}) {
  const state = getState();
  const timePeriod = input.timePeriod || 'Morning peak';
  const totalStudents = Number(input.numberOfStudents || 100);
  const busCount = Number(input.numberOfBuses || state.buses.length);
  const busCapacity = Number(input.busCapacity || 48);

  const beforeOccupancy = state.buses.map((bus) => ({
    busId: bus.id,
    occupancy: Number(((bus.currentPassengers / bus.capacity) * 100).toFixed(1)),
  }));

  const zoneDemand = state.zones.map((zone) => {
    const factor = {
      'Morning peak': 1.3,
      Afternoon: 1.1,
      'Evening peak': 1.4,
      'Normal hours': 0.9,
    }[timePeriod] || 1;

    return {
      zoneId: zone.id,
      zoneName: zone.name,
      demand: Math.round(zone.students * 0.22 * factor + zone.demand * 0.7),
    };
  });

  const adjustedBuses = state.buses.map((bus, index) => {
    const multiplier = index % 2 === 0 ? 1.12 : 0.9;
    const passengers = Math.min(
      bus.capacity,
      Math.round(bus.currentPassengers * multiplier + (totalStudents / busCount) * 0.05)
    );
    return {
      ...bus,
      currentPassengers: passengers,
      occupancy: Number(((passengers / bus.capacity) * 100).toFixed(1)),
    };
  });

  const overcrowded = adjustedBuses.filter((bus) => bus.occupancy > 90);
  const underutilized = adjustedBuses.filter((bus) => bus.occupancy < 50);
  const efficiency = Math.max(
    0,
    Number(((100 - overcrowded.length * 8 - underutilized.length * 4)).toFixed(1))
  );

  const recommendation = adjustedBuses.map((bus) => ({
    busId: bus.id,
    recommendedPassengers: Math.min(bus.capacity, Math.max(20, Math.round(bus.capacity * 0.72))),
    action: bus.occupancy > 90 ? 'Redistribute riders to underutilized bus' : 'Keep route allocation',
  }));

  const result = {
    timePeriod,
    totalStudents,
    busesUsed: busCount,
    busCapacity,
    zoneDemand,
    beforeOccupancy,
    afterOccupancy: adjustedBuses.map((bus) => ({ busId: bus.id, occupancy: bus.occupancy })),
    overcrowded: overcrowded.map((bus) => ({ busId: bus.id, occupancy: bus.occupancy })),
    underutilized: underutilized.map((bus) => ({ busId: bus.id, occupancy: bus.occupancy })),
    recommendedAllocation: recommendation,
    efficiency,
    summary: `Simulation indicates ${overcrowded.length} overcrowded bus(es) and ${underutilized.length} underutilized bus(es).`,
    timestamp: new Date().toISOString(),
  };

  state.simulationResults.unshift(result);
  state.simulationResults = state.simulationResults.slice(0, 20);
  return result;
}

export function getSimulationResults() {
  return getState().simulationResults;
}

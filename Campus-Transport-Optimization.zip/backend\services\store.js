import { createDemoState } from './demoData.js';

let state = createDemoState();

export function getState() {
  return state;
}

export function resetState() {
  state = createDemoState();
  return state;
}

export function getZones() {
  return state.zones;
}

export function getBuses() {
  return state.buses;
}

export function getRoutes() {
  return state.routes;
}

export function getEvents() {
  return state.events;
}

export function setState(newState) {
  state = newState;
}

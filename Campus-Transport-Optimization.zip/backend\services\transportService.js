import { getState } from './store.js';
import { zoneConnections } from './demoData.js';
import { dijkstra } from './routeOptimization.js';
import { triggerEvent as emitTransportEvent } from './eventService.js';

export function getDashboardStats() {
  const state = getState();
  const totalCapacity = state.buses.reduce((sum, bus) => sum + bus.capacity, 0);
  const passengers = state.buses.reduce((sum, bus) => sum + bus.currentPassengers, 0);
  const avgOccupancy = Number(((passengers / totalCapacity) * 100).toFixed(1));

  return {
    totalBuses: state.buses.length,
    activeBuses: state.buses.filter((bus) => bus.status === 'Active').length,
    totalStudents: state.students.length,
    totalZones: state.zones.length,
    averageBusOccupancy: avgOccupancy,
    overcrowdedBuses: state.buses.filter((bus) => bus.occupancy > 90).length,
    underutilizedBuses: state.buses.filter((bus) => bus.occupancy < 50).length,
    activeAlerts: state.alerts || 0,
    recentEvents: state.events.slice(0, 4),
  };
}

export function getZones() {
  return getState().zones;
}

export function addZone(zoneInput = {}) {
  const state = getState();
  const zone = {
    id: zoneInput.id || `Z${state.zones.length + 1}`,
    name: zoneInput.name || 'New Zone',
    students: Number(zoneInput.students || 0),
    demand: Number(zoneInput.demand || 0),
    peakDemand: Number(zoneInput.peakDemand || 0),
    priority: zoneInput.priority || 'Medium',
  };
  state.zones.push(zone);
  return zone;
}

export function updateZone(id, updates = {}) {
  const state = getState();
  const zone = state.zones.find((item) => item.id === id || item.name === id);
  if (!zone) return null;
  Object.assign(zone, updates);
  return zone;
}

export function deleteZone(id) {
  const state = getState();
  const index = state.zones.findIndex((zone) => zone.id === id);
  if (index < 0) return null;
  return state.zones.splice(index, 1)[0];
}

export function getBuses() {
  return getState().buses;
}

export function addBus(busInput = {}) {
  const state = getState();
  const capacity = Number(busInput.capacity || 40);
  const passengers = Number(busInput.currentPassengers || 0);
  const bus = {
    id: busInput.id || `bus-${state.buses.length + 1}`,
    registrationNumber: busInput.registrationNumber || `CB-${state.buses.length + 101}`,
    capacity,
    currentPassengers: Math.min(passengers, capacity),
    assignedRoute: busInput.assignedRoute || 'route-1',
    status: busInput.status || 'Active',
    driverName: busInput.driverName || 'Unassigned',
    estimatedArrivalTime: busInput.estimatedArrivalTime || '10 mins',
    occupancy: Number(((Math.min(passengers, capacity) / capacity) * 100).toFixed(1)),
  };
  state.buses.push(bus);
  return bus;
}

export function updateBus(id, updates = {}) {
  const state = getState();
  const bus = state.buses.find((item) => item.id === id || item.registrationNumber === id);
  if (!bus) return null;
  Object.assign(bus, updates);
  if (updates.currentPassengers !== undefined || updates.capacity !== undefined) {
    const cap = Number(bus.capacity || 1);
    const current = Number(bus.currentPassengers || 0);
    bus.currentPassengers = Math.min(current, cap);
    bus.occupancy = Number(((bus.currentPassengers / cap) * 100).toFixed(1));
  }
  return bus;
}

export function deleteBus(id) {
  const state = getState();
  const index = state.buses.findIndex((bus) => bus.id === id);
  if (index < 0) return null;
  return state.buses.splice(index, 1)[0];
}

export function updateBusStatus(id, status, details = {}) {
  const state = getState();
  const bus = state.buses.find((item) => item.id === id || item.registrationNumber === id);
  if (!bus) return null;
  bus.status = status;
  if (details.delayMinutes !== undefined) bus.delayMinutes = details.delayMinutes;
  if (details.estimatedArrivalTime) bus.estimatedArrivalTime = details.estimatedArrivalTime;
  return bus;
}

export function getRoutes() {
  return getState().routes;
}

export function getRouteById(id) {
  return getState().routes.find((route) => route.id === id) || null;
}

export function optimizeRoutes(payload = {}) {
  const state = getState();
  const graph = payload.graph || zoneConnections;
  const start = payload.startZone || 'A';
  const end = payload.endZone || 'E';
  const routeResult = dijkstra(graph, start, end);

  const ranked = [...state.zones].sort((a, b) => b.demand - a.demand).slice(0, 4);
  const originalDistance = 14.6;
  const optimizedDistance = routeResult.distance || 0;
  const distanceSaved = Math.max(0, originalDistance - optimizedDistance);
  const timeSaved = Math.max(0, Math.round(distanceSaved * 2));

  return {
    originalRoute: 'Current commute loop',
    optimizedRoute: routeResult.path.length ? routeResult.path.join(' → ') : 'No route found',
    originalDistance,
    optimizedDistance,
    estimatedTimeSaved: `${timeSaved} min`,
    estimatedDistanceSaved: `${distanceSaved.toFixed(1)} km`,
    demandCoverage: `${Math.min(100, Math.round(ranked.reduce((sum, zone) => sum + zone.demand, 0) / 2.1))}%`,
    busUtilization: `${Math.min(100, Math.round((state.buses.filter((bus) => bus.status === 'Active').length / state.buses.length) * 100))}%`,
    routeSummary: `Route from ${start} to ${end} is computed using Dijkstra's algorithm on weighted campus-zone graph edges.`,
    path: routeResult.path,
    totalDistance: optimizedDistance,
  };
}

export function getEvents() {
  return getState().events;
}

export function getOccupancyAnalytics() {
  return getState().buses.map((bus) => ({
    busId: bus.id,
    occupancy: bus.occupancy,
    route: bus.assignedRoute,
    status: bus.status,
  }));
}

export function getDemandAnalytics() {
  return getState().zones.map((zone) => ({
    zoneId: zone.id,
    name: zone.name,
    demand: zone.demand,
    peakDemand: zone.peakDemand,
    students: zone.students,
  }));
}

export function triggerEvent(type, payload = {}) {
  return emitTransportEvent(type, payload);
}

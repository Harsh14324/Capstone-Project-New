import test from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../server.js';
import { dijkstra } from '../services/routeOptimization.js';
import { triggerEvent } from '../services/eventService.js';
import { getState } from '../services/store.js';

const app = createApp();

test('health endpoint responds successfully', async () => {
  const server = app.listen(0);
  const port = server.address().port;
  const response = await fetch(`http://127.0.0.1:${port}/api/health`);
  const json = await response.json();
  assert.equal(response.status, 200);
  assert.equal(json.success, true);
  server.close();
});

test('dijkstra computes shortest path between zones', () => {
  const graph = {
    A: { B: 4, D: 5, E: 3 },
    B: { A: 4, C: 6, E: 4 },
    C: { B: 6, F: 7, H: 4 },
    D: { A: 5, E: 3, G: 5 },
    E: { A: 3, B: 4, D: 3, F: 5, H: 4, G: 6 },
    F: { C: 7, E: 5, H: 3 },
    G: { D: 5, E: 6, H: 6 },
    H: { C: 4, E: 4, F: 3, G: 6 },
  };

  const result = dijkstra(graph, 'A', 'F');
  assert.ok(result.path.includes('A'));
  assert.ok(result.path.includes('F'));
  assert.ok(result.distance > 0);
});

test('bus breakdown event updates the bus status', () => {
  const bus = getState().buses.find((item) => item.id === 'bus-10');
  triggerEvent('BUS_BREAKDOWN', { busId: bus.id, severity: 'high' });
  const after = getState().buses.find((item) => item.id === 'bus-10');
  assert.equal(after.status, 'Breakdown');
});

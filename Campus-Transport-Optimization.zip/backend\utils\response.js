export function successResponse(message, data = {}) {
  return { success: true, message, data };
}

export function errorResponse(message, data = {}, statusCode = 500) {
  return { success: false, message, data, statusCode };
}

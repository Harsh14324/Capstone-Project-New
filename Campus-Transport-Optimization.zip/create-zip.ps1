$ErrorActionPreference = 'Stop'

$projectRoot = $PSScriptRoot
$zipPath = Join-Path $projectRoot 'Campus-Transport-Optimization.zip'
$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("campus-transport-zip-" + [guid]::NewGuid())

if (Test-Path $zipPath) {
  Remove-Item $zipPath -Force
}

New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null

Get-ChildItem $projectRoot -Force | Where-Object {
  $_.Name -notin @('node_modules', '.git', '.env', '.env.local', 'Campus-Transport-Optimization.zip', 'dist', '.vite')
} | ForEach-Object {
  Copy-Item $_.FullName -Destination (Join-Path $tempRoot $_.Name) -Recurse -Force
}

Compress-Archive -Path (Join-Path $tempRoot '*') -DestinationPath $zipPath -Force
Remove-Item $tempRoot -Recurse -Force

Write-Host "Archive created: $zipPath"

import { Navigate, Route, Routes } from 'react-router-dom';
import Layout from './components/Layout.jsx';
import { DemoProvider, useDemoContext } from './context/DemoContext.jsx';
import Login from './pages/Login.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Zones from './pages/Zones.jsx';
import Buses from './pages/Buses.jsx';
import RoutesPage from './pages/Routes.jsx';
import Simulation from './pages/Simulation.jsx';
import Operations from './pages/Operations.jsx';
import EventsPage from './pages/Events.jsx';
import Analytics from './pages/Analytics.jsx';
import Settings from './pages/Settings.jsx';

function AppRoutes() {
  const { isLoggedIn } = useDemoContext();

  return isLoggedIn ? (
    <Layout>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/zones" element={<Zones />} />
        <Route path="/buses" element={<Buses />} />
        <Route path="/routes" element={<RoutesPage />} />
        <Route path="/simulation" element={<Simulation />} />
        <Route path="/operations" element={<Operations />} />
        <Route path="/events" element={<EventsPage />} />
        <Route path="/analytics" element={<Analytics />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Layout>
  ) : (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <DemoProvider>
      <AppRoutes />
    </DemoProvider>
  );
}

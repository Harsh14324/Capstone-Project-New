import { BarChart3, Bell, CalendarClock, CircleUserRound, Compass, LayoutDashboard, LogOut, Menu, Settings, TrainFront, Truck, Zap } from 'lucide-react';
import { NavLink, useLocation } from 'react-router-dom';
import { useDemoContext } from '../context/DemoContext.jsx';

const navigation = [
  { name: 'Dashboard', path: '/', icon: LayoutDashboard },
  { name: 'Campus Zones', path: '/zones', icon: Compass },
  { name: 'Bus Management', path: '/buses', icon: Truck },
  { name: 'Route Optimization', path: '/routes', icon: TrainFront },
  { name: 'Demand Simulation', path: '/simulation', icon: Zap },
  { name: 'Live Operations', path: '/operations', icon: BarChart3 },
  { name: 'Events & Alerts', path: '/events', icon: Bell },
  { name: 'Analytics & Reports', path: '/analytics', icon: CalendarClock },
  { name: 'Settings', path: '/settings', icon: Settings },
];

export default function Layout({ children }) {
  const { theme, setTheme } = useDemoContext();
  const location = useLocation();

  return (
    <div className={`app-shell ${theme}`}>
      <aside className="sidebar">
        <div className="brand-block">
          <div className="brand-mark">CT</div>
          <div>
            <p className="eyebrow">Operations</p>
            <h2>Campus Transit</h2>
          </div>
        </div>

        <nav className="side-nav">
          {navigation.map(({ name, path, icon: Icon }) => (
            <NavLink
              key={path}
              to={path}
              className={({ isActive }) => `nav-link ${isActive || (path === '/' && location.pathname === '/') ? 'active' : ''}`}
            >
              <Icon size={17} />
              <span>{name}</span>
            </NavLink>
          ))}
        </nav>

        <div className="sidebar-footer">
          <button className="ghost-button">
            <Menu size={16} />
            Collapse
          </button>
        </div>
      </aside>

      <div className="main-panel">
        <header className="topbar">
          <div>
            <p className="eyebrow">Project overview</p>
            <h1>Campus Transport Optimization System</h1>
          </div>
          <div className="topbar-actions">
            <div className="date-pill">{new Date().toLocaleString()}</div>
            <button className="icon-button" aria-label="notifications"><Bell size={18} /></button>
            <button className="icon-button" onClick={() => setTheme((current) => (current === 'dark' ? 'light' : 'dark'))}>
              {theme === 'dark' ? '☀️' : '🌙'}
            </button>
            <div className="profile-chip">
              <CircleUserRound size={18} />
              <span>Admin</span>
            </div>
            <button className="ghost-button">
              <LogOut size={16} />
              Logout
            </button>
          </div>
        </header>

        <main className="page-content">{children}</main>
      </div>
    </div>
  );
}

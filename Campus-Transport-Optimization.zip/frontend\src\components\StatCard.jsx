export default function StatCard({ title, value, trend, accent = 'blue' }) {
  return (
    <div className="stat-card">
      <div className="stat-header">
        <span>{title}</span>
        <span className={`badge ${accent}`}>{trend || 'Live'}</span>
      </div>
      <h3>{value}</h3>
    </div>
  );
}

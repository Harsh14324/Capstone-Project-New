import { createContext, useContext, useMemo, useState } from 'react';

const DemoContext = createContext();

export function DemoProvider({ children }) {
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const [theme, setTheme] = useState('dark');

  const value = useMemo(() => ({ isLoggedIn, setIsLoggedIn, theme, setTheme }), [isLoggedIn, theme]);

  return <DemoContext.Provider value={value}>{children}</DemoContext.Provider>;
}

export function useDemoContext() {
  return useContext(DemoContext);
}

import { useEffect, useState } from 'react';
import { apiRequest } from '../services/api.js';

export default function Analytics() {
  const [occupancy, setOccupancy] = useState([]);
  const [demand, setDemand] = useState([]);

  useEffect(() => {
    Promise.all([apiRequest('/analytics/occupancy'), apiRequest('/analytics/demand')]).then(([occupancyResponse, demandResponse]) => {
      setOccupancy(occupancyResponse.data || []);
      setDemand(demandResponse.data || []);
    });
  }, []);

  return (
    <div>
      <div className="page-header">
        <div>
          <p className="eyebrow">Reporting</p>
          <h2>Analytics & reports</h2>
        </div>
      </div>

      <div className="two-column-grid">
        <div className="panel summary-panel">
          <h3>Occupancy analytics</h3>
          <ul className="event-list compact">
            {occupancy.map((item) => (
              <li key={item.busId}><span>{item.busId}</span><span>{item.occupancy}%</span></li>
            ))}
          </ul>
        </div>

        <div className="panel summary-panel">
          <h3>Demand analytics</h3>
          <ul className="event-list compact">
            {demand.map((item) => (
              <li key={item.zoneId}><span>{item.name}</span><span>{item.demand}</span></li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

import { useEffect, useState } from 'react';
import { apiRequest } from '../services/api.js';

export default function Buses() {
  const [buses, setBuses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiRequest('/buses').then((response) => setBuses(response.data || [])).finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <div className="page-header">
        <div>
          <p className="eyebrow">Fleet overview</p>
          <h2>Bus management</h2>
        </div>
        <button className="primary-button">Add bus</button>
      </div>

      {loading ? <div className="panel loading-panel">Loading buses…</div> : (
        <div className="table-panel panel">
          <table>
            <thead>
              <tr>
                <th>Bus ID</th>
                <th>Registration</th>
                <th>Capacity</th>
                <th>Passengers</th>
                <th>Route</th>
                <th>Status</th>
                <th>Occupancy</th>
              </tr>
            </thead>
            <tbody>
              {buses.map((bus) => (
                <tr key={bus.id}>
                  <td>{bus.id}</td>
                  <td>{bus.registrationNumber}</td>
                  <td>{bus.capacity}</td>
                  <td>{bus.currentPassengers}</td>
                  <td>{bus.assignedRoute}</td>
                  <td><span className="status-badge">{bus.status}</span></td>
                  <td>{bus.occupancy}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

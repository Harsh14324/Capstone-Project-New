import { useEffect, useState } from 'react';
import { Activity, AlertTriangle, Bus, Route, Users } from 'lucide-react';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, ResponsiveContainer, XAxis, YAxis, Tooltip } from 'recharts';
import StatCard from '../components/StatCard.jsx';
import { apiRequest } from '../services/api.js';

const palette = ['#4f7cff', '#70d6ff', '#8b5cf6', '#34d399', '#fbbf24'];

export default function Dashboard() {
  const [stats, setStats] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadStats = async () => {
      try {
        const response = await apiRequest('/dashboard/stats');
        setStats(response.data || {});
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    };
    loadStats();
  }, []);

  const occupancyChart = [
    { name: 'Bus 1', occupancy: 65 },
    { name: 'Bus 2', occupancy: 54 },
    { name: 'Bus 3', occupancy: 92 },
    { name: 'Bus 4', occupancy: 31 },
    { name: 'Bus 5', occupancy: 90 },
    { name: 'Bus 6', occupancy: 38 },
  ];

  const demandChart = [
    { name: '08:00', demand: 60 },
    { name: '09:00', demand: 92 },
    { name: '10:00', demand: 88 },
    { name: '12:00', demand: 72 },
    { name: '14:00', demand: 96 },
    { name: '17:00', demand: 122 },
  ];

  const utilizationData = [
    { name: 'Healthy', value: 58 },
    { name: 'Overcrowded', value: 22 },
    { name: 'Underutilized', value: 20 },
  ];

  return (
    <div>
      <div className="page-header">
        <div>
          <p className="eyebrow">Operations snapshot</p>
          <h2>Transport dashboard</h2>
        </div>
        <button className="primary-button">Run optimization</button>
      </div>

      {loading ? <div className="panel loading-panel">Loading dashboard metrics…</div> : (
        <div className="stats-grid">
          <StatCard title="Total buses" value={stats.totalBuses ?? 10} trend="Live" accent="blue" />
          <StatCard title="Active buses" value={stats.activeBuses ?? 7} trend="Active" accent="green" />
          <StatCard title="Total students" value={stats.totalStudents ?? 100} trend="Demo" accent="violet" />
          <StatCard title="Campus zones" value={stats.totalZones ?? 8} trend="8" accent="cyan" />
          <StatCard title="Avg occupancy" value={`${stats.averageBusOccupancy ?? 62}%`} trend="Target" accent="gold" />
          <StatCard title="Overcrowded" value={stats.overcrowdedBuses ?? 2} trend="Alert" accent="red" />
          <StatCard title="Underutilized" value={stats.underutilizedBuses ?? 2} trend="Watch" accent="amber" />
          <StatCard title="Active alerts" value={stats.activeAlerts ?? 3} trend="Critical" accent="red" />
        </div>
      )}

      <div className="two-column-grid">
        <div className="panel chart-panel">
          <div className="panel-header"><Bus size={18} /> <h3>Bus occupancy</h3></div>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={occupancyChart}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="occupancy" radius={[8, 8, 0, 0]} fill="#5b8cff" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="panel chart-panel">
          <div className="panel-header"><Activity size={18} /> <h3>Passenger demand</h3></div>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={demandChart}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="demand" stroke="#7c3aed" strokeWidth={3} dot={{ r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="two-column-grid">
        <div className="panel chart-panel">
          <div className="panel-header"><Route size={18} /> <h3>Peak-hour demand</h3></div>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={demandChart}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="demand" fill="#22d3ee" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="panel chart-panel">
          <div className="panel-header"><Users size={18} /> <h3>Bus utilization</h3></div>
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie data={utilizationData} dataKey="value" nameKey="name" outerRadius={80} innerRadius={40} paddingAngle={4}>
                {utilizationData.map((entry, index) => <Cell key={entry.name} fill={palette[index % palette.length]} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="panel summary-panel">
        <div className="panel-header"><AlertTriangle size={18} /> <h3>Recent transport events</h3></div>
        <ul className="event-list">
          {(stats.recentEvents || []).map((event) => (
            <li key={event.id || event.type}><span className="event-type">{event.type}</span><span>{event.description}</span></li>
          ))}
        </ul>
      </div>
    </div>
  );
}

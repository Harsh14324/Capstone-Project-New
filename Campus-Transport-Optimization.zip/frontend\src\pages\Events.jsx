import { useEffect, useState } from 'react';
import { apiRequest } from '../services/api.js';

export default function EventsPage() {
  const [events, setEvents] = useState([]);

  const triggerEvent = async (type) => {
    await apiRequest('/events/trigger', 'POST', {
      type,
      payload: { severity: 'high', description: `Manual demo trigger: ${type}`, busId: 'bus-10' },
    });
    const response = await apiRequest('/events');
    setEvents(response.data || []);
  };

  useEffect(() => {
    apiRequest('/events').then((response) => setEvents(response.data || []));
  }, []);

  return (
    <div>
      <div className="page-header">
        <div>
          <p className="eyebrow">Incident management</p>
          <h2>Events & alerts</h2>
        </div>
        <button className="primary-button" onClick={() => triggerEvent('BUS_BREAKDOWN')}>Trigger event</button>
      </div>

      <div className="panel summary-panel">
        <ul className="event-list">
          {events.map((event) => (
            <li key={event.id}><span className="event-type">{event.type}</span><span>{event.description}</span></li>
          ))}
        </ul>
      </div>
    </div>
  );
}

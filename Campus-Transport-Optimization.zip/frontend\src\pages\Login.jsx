import { ArrowRight, ShieldCheck } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useDemoContext } from '../context/DemoContext.jsx';

export default function Login() {
  const navigate = useNavigate();
  const { setIsLoggedIn } = useDemoContext();

  const handleDemoAccess = () => {
    setIsLoggedIn(true);
    navigate('/');
  };

  return (
    <div className="login-wrap">
      <div className="login-card">
        <div className="login-badge"><ShieldCheck size={18} /> Demo access enabled</div>
        <h1>Campus Transport Optimization</h1>
        <p>Access the live demonstration dashboard for campus zone planning, route optimization, and demand simulation.</p>
        <button className="primary-button" onClick={handleDemoAccess}>
          Continue to demo dashboard <ArrowRight size={16} />
        </button>
      </div>
    </div>
  );
}

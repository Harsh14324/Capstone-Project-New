import { useEffect, useState } from 'react';
import { apiRequest } from '../services/api.js';

export default function Operations() {
  const [buses, setBuses] = useState([]);
  const [events, setEvents] = useState([]);

  useEffect(() => {
    Promise.all([apiRequest('/buses'), apiRequest('/events')]).then(([busesResponse, eventsResponse]) => {
      setBuses(busesResponse.data || []);
      setEvents(eventsResponse.data || []);
    });
  }, []);

  return (
    <div>
      <div className="page-header">
        <div>
          <p className="eyebrow">Live monitoring</p>
          <h2>Live operations</h2>
        </div>
      </div>

      <div className="table-panel panel">
        <table>
          <thead>
            <tr>
              <th>Bus</th>
              <th>Status</th>
              <th>Route</th>
              <th>Passengers</th>
              <th>Occupancy</th>
              <th>Delay</th>
            </tr>
          </thead>
          <tbody>
            {buses.map((bus) => (
              <tr key={bus.id}>
                <td>{bus.registrationNumber}</td>
                <td><span className="status-badge">{bus.status}</span></td>
                <td>{bus.assignedRoute}</td>
                <td>{bus.currentPassengers}</td>
                <td>{bus.occupancy}%</td>
                <td>{bus.delayMinutes || 'None'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="panel summary-panel">
        <h3>Recent events</h3>
        <ul className="event-list">
          {events.map((event) => (
            <li key={event.id}><span className="event-type">{event.type}</span><span>{event.description}</span></li>
          ))}
        </ul>
      </div>
    </div>
  );
}

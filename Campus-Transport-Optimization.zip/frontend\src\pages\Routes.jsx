import { useEffect, useState } from 'react';
import { apiRequest } from '../services/api.js';

export default function RoutesPage() {
  const [routes, setRoutes] = useState([]);
  const [optimization, setOptimization] = useState(null);

  useEffect(() => {
    Promise.all([
      apiRequest('/routes'),
      apiRequest('/routes/optimize', 'POST', { startZone: 'A', endZone: 'E' }),
    ]).then(([routeResponse, optimizeResponse]) => {
      setRoutes(routeResponse.data || []);
      setOptimization(optimizeResponse.data || null);
    });
  }, []);

  return (
    <div>
      <div className="page-header">
        <div>
          <p className="eyebrow">Optimization engine</p>
          <h2>Route optimization</h2>
        </div>
        <button className="primary-button">Run route optimization</button>
      </div>

      {optimization && (
        <div className="panel summary-panel">
          <h3>Optimization result</h3>
          <p>{optimization.routeSummary}</p>
          <div className="metrics-row">
            <div><strong>Original distance</strong><span>{optimization.originalDistance} km</span></div>
            <div><strong>Optimized distance</strong><span>{optimization.optimizedDistance} km</span></div>
            <div><strong>Time saved</strong><span>{optimization.estimatedTimeSaved}</span></div>
            <div><strong>Demand coverage</strong><span>{optimization.demandCoverage}</span></div>
          </div>
        </div>
      )}

      <div className="table-panel panel">
        <table>
          <thead>
            <tr>
              <th>Route</th>
              <th>From</th>
              <th>To</th>
              <th>Distance</th>
              <th>Time</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {routes.map((route) => (
              <tr key={route.id}>
                <td>{route.name}</td>
                <td>{route.from}</td>
                <td>{route.to}</td>
                <td>{route.distance} km</td>
                <td>{route.time} min</td>
                <td><span className="status-badge">{route.status}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default function Settings() {
  return (
    <div>
      <div className="page-header">
        <div>
          <p className="eyebrow">Configuration</p>
          <h2>Settings</h2>
        </div>
      </div>

      <div className="panel summary-panel">
        <h3>System settings</h3>
        <div className="settings-grid">
          <div><strong>API mode</strong><span>Demo + offline mode</span></div>
          <div><strong>Database</strong><span>MongoDB Atlas optional</span></div>
          <div><strong>Theme</strong><span>Dark / light toggle enabled</span></div>
          <div><strong>Auto-refresh</strong><span>15-second operations polling</span></div>
        </div>
      </div>
    </div>
  );
}

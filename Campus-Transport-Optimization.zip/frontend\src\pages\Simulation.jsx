import { useEffect, useState } from 'react';
import { apiRequest } from '../services/api.js';

export default function Simulation() {
  const [results, setResults] = useState([]);
  const [summary, setSummary] = useState(null);

  const runSimulation = async () => {
    const response = await apiRequest('/simulation/run', 'POST', {
      timePeriod: 'Morning peak',
      numberOfStudents: 120,
      numberOfBuses: 10,
      busCapacity: 48,
    });
    setSummary(response.data || null);
    loadResults();
  };

  const loadResults = async () => {
    const response = await apiRequest('/simulation/results');
    setResults(response.data || []);
  };

  useEffect(() => {
    loadResults();
  }, []);

  return (
    <div>
      <div className="page-header">
        <div>
          <p className="eyebrow">Demand planning</p>
          <h2>Demand simulation</h2>
        </div>
        <button className="primary-button" onClick={runSimulation}>Run simulation</button>
      </div>

      {summary && (
        <div className="panel summary-panel">
          <h3>Simulation summary</h3>
          <p>{summary.summary}</p>
          <div className="metrics-row">
            <div><strong>Efficiency</strong><span>{summary.efficiency}%</span></div>
            <div><strong>Overcrowded</strong><span>{summary.overcrowded?.length ?? 0}</span></div>
            <div><strong>Underutilized</strong><span>{summary.underutilized?.length ?? 0}</span></div>
          </div>
        </div>
      )}

      <div className="table-panel panel">
        <table>
          <thead>
            <tr>
              <th>Time period</th>
              <th>Students</th>
              <th>Bus capacity</th>
              <th>Efficiency</th>
              <th>Summary</th>
            </tr>
          </thead>
          <tbody>
            {results.map((result, index) => (
              <tr key={`${result.timestamp}-${index}`}>
                <td>{result.timePeriod}</td>
                <td>{result.totalStudents}</td>
                <td>{result.busCapacity}</td>
                <td>{result.efficiency}%</td>
                <td>{result.summary}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

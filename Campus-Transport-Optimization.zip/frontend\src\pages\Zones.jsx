import { useEffect, useState } from 'react';
import { apiRequest } from '../services/api.js';

export default function Zones() {
  const [zones, setZones] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiRequest('/zones').then((response) => setZones(response.data || [])).finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <div className="page-header">
        <div>
          <p className="eyebrow">Campus operations</p>
          <h2>Campus zones</h2>
        </div>
        <button className="primary-button">Add zone</button>
      </div>

      {loading ? <div className="panel loading-panel">Loading campus zones…</div> : (
        <div className="table-panel panel">
          <table>
            <thead>
              <tr>
                <th>Zone ID</th>
                <th>Zone name</th>
                <th>Students</th>
                <th>Demand</th>
                <th>Peak hour</th>
                <th>Priority</th>
              </tr>
            </thead>
            <tbody>
              {zones.map((zone) => (
                <tr key={zone.id}>
                  <td>{zone.id}</td>
                  <td>{zone.name}</td>
                  <td>{zone.students}</td>
                  <td>{zone.demand}</td>
                  <td>{zone.peakDemand}</td>
                  <td><span className="priority-tag">{zone.priority}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api',
  timeout: 15000,
});

export const apiRequest = async (url, method = 'GET', data = null) => {
  const response = await api.request({ url, method, data });
  return response.data;
};

export default api;
